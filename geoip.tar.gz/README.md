# Shift8 GEO Ip 
* Contributors: shift8
* Donate link: https://www.shift8web.ca
* Tags: ip address, geo-location, geolocation, geo ip, geo targeting, ip address cookie, ip cookie, geographic location, ip address location, ip location 
* Requires at least: 3.0.1
* Tested up to: 4.8
* Stable tag: 1.00
* License: GPLv3
* License URI: http://www.gnu.org/licenses/gpl-3.0.html

Plugin that establishes an IP Address geo-location coordinate that is then set in an encrypted cookie variable

## Want to see the plugin in action?

You can view two example sites where this plugin is live :

- Example Site 1 : [Wordpress Hosting](https://www.stackstar.com "Wordpress Hosting")
- Example Site 2 : [Web Design in Toronto](https://www.shift8web.ca "Web Design in Toronto")
- Example Site 3 : [Dope Mail](https://dopemail.com "Buy weed online")

## Features 

- Encrypted cookie session containing the IP Geo-Location coordinates


## Installation 

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/shif8-geoip` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Navigate to the plugin settings page and define your settings
3. Once enabled, the system should trigger and set a cookie for every site visit.

## Frequently Asked Questions 

### I tested it and its not setting the cookie for me!

Try a different browser, perhaps one that is not logged into the Wordpress administration area

### Screenshots 

1. Admin area 
2. Rules definitions

## Changelog 

### 1.0 
* Stable version created
